package com.tom.VendingMachine;

public interface Capsule {
	Describable open();
}
