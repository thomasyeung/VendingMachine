package com.tom.VendingMachine;

public interface CapsuleFactory {
	Object makeRandom();
}
