package com.tom.VendingMachine;

public interface Describable {
	String getDescription();
}
