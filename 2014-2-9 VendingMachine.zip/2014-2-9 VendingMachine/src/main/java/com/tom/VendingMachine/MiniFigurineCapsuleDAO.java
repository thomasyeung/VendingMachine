package com.tom.VendingMachine;

public class MiniFigurineCapsuleDAO extends HibernateDAO {

	public MiniFigurineCapsuleDAO() {
		super(MiniFigurineCapsule.class);
	}
	

}
