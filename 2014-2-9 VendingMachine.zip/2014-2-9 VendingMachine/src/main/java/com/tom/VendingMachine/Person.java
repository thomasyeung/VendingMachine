package com.tom.VendingMachine;

public interface Person {
	void interact(VendingMachine vm) throws Exception;
}
