package com.tom.VendingMachine;

public class StickerCapsuleDAO extends HibernateDAO {
	
	public StickerCapsuleDAO( ) {
		super(StickerCapsule.class);
	}
}
