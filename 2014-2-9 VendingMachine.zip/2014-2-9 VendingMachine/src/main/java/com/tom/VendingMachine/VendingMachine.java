package com.tom.VendingMachine;

public interface VendingMachine {
	Object turnKnob();
	void refill();
}
